-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: maine_covid
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `alc_agg_level_codes`
--

LOCK TABLES `alc_agg_level_codes` WRITE;
/*!40000 ALTER TABLE `alc_agg_level_codes` DISABLE KEYS */;
INSERT INTO `alc_agg_level_codes` VALUES ('2ba948b7-c102-11ee-86d3-047c163f0179',10,'National, Total Covered'),('2ba96907-c102-11ee-86d3-047c163f0179',11,'National, Total -- by ownership sector'),('2ba97529-c102-11ee-86d3-047c163f0179',12,'National, by Domain -- by ownership sector'),('2ba97742-c102-11ee-86d3-047c163f0179',13,'National, by Supersector -- by ownership sector'),('2ba97836-c102-11ee-86d3-047c163f0179',14,'National, NAICS Sector -- by ownership sector'),('2ba9792c-c102-11ee-86d3-047c163f0179',15,'National, NAICS 3-digit -- by ownership sector'),('2ba979ef-c102-11ee-86d3-047c163f0179',16,'National, NAICS 4-digit -- by ownership sector'),('2ba97ac8-c102-11ee-86d3-047c163f0179',17,'National, NAICS 5-digit -- by ownership sector'),('2ba97b8f-c102-11ee-86d3-047c163f0179',18,'National, NAICS 6-digit -- by ownership sector'),('2ba97c5e-c102-11ee-86d3-047c163f0179',21,'National, Private, total, by establishment size class'),('2ba97d13-c102-11ee-86d3-047c163f0179',22,'National, Private, Domain, by establishment size class'),('2ba97de5-c102-11ee-86d3-047c163f0179',23,'National, Private, by Supersector, by establishment size class'),('2ba97ed1-c102-11ee-86d3-047c163f0179',24,'National, Private, NAICS Sector, by establishment size class'),('2ba97f4f-c102-11ee-86d3-047c163f0179',25,'National, Private, NAICS 3-digit, by establishment size class'),('2ba97fcf-c102-11ee-86d3-047c163f0179',26,'National, Private, NAICS 4-digit, by establishment size class'),('2ba98069-c102-11ee-86d3-047c163f0179',27,'National, Private, NAICS 5-digit, by establishment size class'),('2ba980c6-c102-11ee-86d3-047c163f0179',28,'National, Private, NAICS 6-digit, by establishment size class'),('2ba9816e-c102-11ee-86d3-047c163f0179',30,'CMSA or CSA, Total Covered'),('2ba981ec-c102-11ee-86d3-047c163f0179',40,'MSA, Total Covered'),('2ba98263-c102-11ee-86d3-047c163f0179',41,'MSA, Total -- by ownership sector'),('2ba982f2-c102-11ee-86d3-047c163f0179',42,'MSA, by Domain -- by ownership sector'),('2ba9837f-c102-11ee-86d3-047c163f0179',43,'MSA, by Supersector -- by ownership sector'),('2ba983f9-c102-11ee-86d3-047c163f0179',44,'MSA, NAICS Sector -- by ownership sector'),('2ba984ac-c102-11ee-86d3-047c163f0179',45,'MSA, NAICS 3-digit -- by ownership sector'),('2ba98552-c102-11ee-86d3-047c163f0179',46,'MSA, NAICS 4-digit -- by ownership sector'),('2ba985dc-c102-11ee-86d3-047c163f0179',47,'MSA, NAICS 5-digit -- by ownership sector'),('2ba9863c-c102-11ee-86d3-047c163f0179',48,'MSA, NAICS 6-digit -- by ownership sector'),('2ba98696-c102-11ee-86d3-047c163f0179',50,'State, Total Covered'),('2ba986e6-c102-11ee-86d3-047c163f0179',51,'State, Total -- by ownership sector'),('2ba98744-c102-11ee-86d3-047c163f0179',52,'State, by Domain -- by ownership sector'),('2ba9879f-c102-11ee-86d3-047c163f0179',53,'State, by Supersector -- by ownership sector'),('2ba98825-c102-11ee-86d3-047c163f0179',54,'State, NAICS Sector -- by ownership sector'),('2ba98887-c102-11ee-86d3-047c163f0179',55,'State, NAICS 3-digit -- by ownership sector'),('2ba988eb-c102-11ee-86d3-047c163f0179',56,'State, NAICS 4-digit -- by ownership sector'),('2ba98945-c102-11ee-86d3-047c163f0179',57,'State, NAICS 5-digit -- by ownership sector'),('2ba9899a-c102-11ee-86d3-047c163f0179',58,'State, NAICS 6-digit -- by ownership sector'),('2ba98a12-c102-11ee-86d3-047c163f0179',61,'State, Private, total, by establishment size class'),('2ba98a60-c102-11ee-86d3-047c163f0179',62,'State, Private, Domain, by establishment size class'),('2ba98aad-c102-11ee-86d3-047c163f0179',63,'State, Private, by Supersector, by establishment size class'),('2ba98afe-c102-11ee-86d3-047c163f0179',64,'State, Private, NAICS Sector, by establishment size class'),('2ba98b56-c102-11ee-86d3-047c163f0179',70,'County, Total Covered'),('2ba98ba9-c102-11ee-86d3-047c163f0179',71,'County, Total -- by ownership sector'),('2ba98bf3-c102-11ee-86d3-047c163f0179',72,'County, by Domain -- by ownership sector'),('2ba98c44-c102-11ee-86d3-047c163f0179',73,'County, by Supersector -- by ownership sector'),('2ba98c9b-c102-11ee-86d3-047c163f0179',74,'County, NAICS Sector -- by ownership sector'),('2ba98ce8-c102-11ee-86d3-047c163f0179',75,'County, NAICS 3-digit -- by ownership sector'),('2ba98d60-c102-11ee-86d3-047c163f0179',76,'County, NAICS 4-digit -- by ownership sector'),('2ba98ddb-c102-11ee-86d3-047c163f0179',77,'County, NAICS 5-digit -- by ownership sector'),('2ba98e2e-c102-11ee-86d3-047c163f0179',78,'County, NAICS 6-digit -- by ownership sector'),('2ba98e7e-c102-11ee-86d3-047c163f0179',80,'MicroSA, Total Covered'),('2ba98eca-c102-11ee-86d3-047c163f0179',91,'Total, all U.S. MSAs'),('2ba98f21-c102-11ee-86d3-047c163f0179',92,'Total, all U.S. CMSAs or all U.S. CSAs'),('2ba98f74-c102-11ee-86d3-047c163f0179',93,'Total, all U.S. non-MSA counties'),('2ba98fd0-c102-11ee-86d3-047c163f0179',94,'Total U.I. Covered (U.S.)'),('2ba9901f-c102-11ee-86d3-047c163f0179',95,'Total Government (U.S.)'),('2ba99077-c102-11ee-86d3-047c163f0179',96,'Total Government, by State');
/*!40000 ALTER TABLE `alc_agg_level_codes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-05 19:39:54
