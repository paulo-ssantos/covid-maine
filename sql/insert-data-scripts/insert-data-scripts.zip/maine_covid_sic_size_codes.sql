-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: maine_covid
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `sic_size_codes`
--

LOCK TABLES `sic_size_codes` WRITE;
/*!40000 ALTER TABLE `sic_size_codes` DISABLE KEYS */;
INSERT INTO `sic_size_codes` VALUES ('8761710e-c103-11ee-86d3-047c163f0179',0,'All establishment sizes'),('87617633-c103-11ee-86d3-047c163f0179',1,'Fewer than 5 employees per establishment'),('87617717-c103-11ee-86d3-047c163f0179',2,'5 to 9 employees per establishment'),('8761777e-c103-11ee-86d3-047c163f0179',3,'10 to 19 employees per establishment'),('876177cb-c103-11ee-86d3-047c163f0179',4,'20 to 49 employees per establishment'),('8761781d-c103-11ee-86d3-047c163f0179',5,'50 to 99 employees per establishment'),('87617868-c103-11ee-86d3-047c163f0179',6,'100 to 249 employees per establishment'),('876178ff-c103-11ee-86d3-047c163f0179',7,'250 to 499 employees per establishment'),('876179a0-c103-11ee-86d3-047c163f0179',8,'500 to 999 employees per establishment'),('87617a25-c103-11ee-86d3-047c163f0179',9,'1000 or more employees per establishment');
/*!40000 ALTER TABLE `sic_size_codes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-05 19:39:58
