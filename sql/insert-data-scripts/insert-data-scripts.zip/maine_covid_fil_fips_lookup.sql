-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: maine_covid
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `fil_fips_lookup`
--

LOCK TABLES `fil_fips_lookup` WRITE;
/*!40000 ALTER TABLE `fil_fips_lookup` DISABLE KEYS */;
INSERT INTO `fil_fips_lookup` VALUES ('602a9c66-c102-11ee-86d3-047c163f0179',23001,'Androscoggin County, Maine'),('602aa1de-c102-11ee-86d3-047c163f0179',23003,'Aroostook County, Maine'),('602aa2bd-c102-11ee-86d3-047c163f0179',23005,'Cumberland County, Maine'),('602aa31a-c102-11ee-86d3-047c163f0179',23007,'Franklin County, Maine'),('602aa368-c102-11ee-86d3-047c163f0179',23009,'Hancock County, Maine'),('602aa3b7-c102-11ee-86d3-047c163f0179',23011,'Kennebec County, Maine'),('602aa412-c102-11ee-86d3-047c163f0179',23013,'Knox County, Maine'),('602aa485-c102-11ee-86d3-047c163f0179',23015,'Lincoln County, Maine'),('602aa4eb-c102-11ee-86d3-047c163f0179',23017,'Oxford County, Maine'),('602aa533-c102-11ee-86d3-047c163f0179',23019,'Penobscot County, Maine'),('602aa586-c102-11ee-86d3-047c163f0179',23021,'Piscataquis County, Maine'),('602aa5d7-c102-11ee-86d3-047c163f0179',23023,'Sagadahoc County, Maine'),('602aa61e-c102-11ee-86d3-047c163f0179',23025,'Somerset County, Maine'),('602aa686-c102-11ee-86d3-047c163f0179',23027,'Waldo County, Maine'),('602aa6d3-c102-11ee-86d3-047c163f0179',23029,'Washington County, Maine'),('602aa719-c102-11ee-86d3-047c163f0179',23031,'York County, Maine'),('602aa77c-c102-11ee-86d3-047c163f0179',23996,'Overseas Locations -- Maine'),('602aa7c7-c102-11ee-86d3-047c163f0179',23998,'Out-of-State, Maine'),('602aa80d-c102-11ee-86d3-047c163f0179',23999,'Unknown Or Undefined, Maine');
/*!40000 ALTER TABLE `fil_fips_lookup` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-05 19:39:54
